# telegramBotUtilities
This is a simple java library to manage bots.
Set-up and code examples at http://leocus.altervista.org/telegrambotutilities.
This software is distributed under "The Unlicense" license.
