package org.altervista.leocus.telegrambotutilities;

public class EmptyUpdatesException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
