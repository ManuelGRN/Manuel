package org.altervista.leocus.telegrambotutilities;

public class GettingUpdatesException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
